// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved
//
// File Name:
//
//    v4PrintDriver-Intellisense.js
//
// Abstract:
//
//    This file defines intellisense to be used by JavaScript extensions in v4 print drivers.

var v4PrintDriverIntellisense = {
    /// <summary>Intended for use by v4 print driver JavaScript Intellisense.</summary>
    createInterface: function (childInterface, baseType, prototype) {
        /// <summary>Intended for use by v4 print driver JavaScript Intellisense.</summary>
        childInterface.__class = true;

        if (prototype) {
            childInterface.prototype = prototype;
        }

        if (baseType) {
            childInterface.__baseType = baseType;
            childInterface.__basePrototypePending = true;
            v4PrintDriverIntellisense.resolveInheritance(childInterface);
        }
    },
    appendInterfaceMethods: function (baseType, prototype) {
        /// <summary>Intended for use by v4 print driver JavaScript Intellisense.</summary>
        for (var memberName in prototype) {
            baseType.prototype[memberName] = prototype[memberName];
        }
    },
    resolveInheritance: function (childInterface) {
        /// <summary>Intended for use by v4 print driver JavaScript Intellisense.</summary>
        var baseType = childInterface.__baseType;
        if (!baseType) {
            return;
        }

        if (baseType.__baseType) {
            resolveInheritance(baseType);
        }

        if (!childInterface.__basePrototypePending) {
            return;
        }

        for (var memberName in baseType.prototype) {
            var memberValue = baseType.prototype[memberName];
            if (!childInterface.prototype[memberName]) {
                childInterface.prototype[memberName] = memberValue;
            }
        }

        delete childInterface.__basePrototypePending;
    }
}

IPrintSchemaElement = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaElement,
    null,
    {
        /// <field name="XmlNode" type="XML DOM">
        /// Property-get maps to COM IPrintSchemaElement::XmlNode.
        /// </field>
        XmlNode: null,
        /// <field name="Name" type="String">
        /// Property-get maps to COM IPrintSchemaElement::Name.
        /// </field>
        Name: null,
        /// <field name="NamespaceUri" type="String">
        /// Property-get maps to COM IPrintSchemaElement::NamespaceUri.
        /// </field>
        NamespaceUri: null
    });

IPrintSchemaDisplayableElement = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaDisplayableElement,
    IPrintSchemaElement,
    {
        /// <field name="DisplayName" type="String">
        /// Property-get maps to COM IPrintSchemaDisplayableElement::DisplayName.
        /// </field>
        DisplayName: null
    });


IPrintSchemaOption = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaOption,
    IPrintSchemaDisplayableElement,
    {
        /// <field name="Selected" type="Boolean">
        /// Property-get maps to COM IPrintSchemaOption::Selected.
        /// </field>
        Selected: null,
        /// <field name="Constrained"  type="PrintSchemaConstrainedSetting">
        /// Property-get maps to COM IPrintSchemaOption::Constrained.
        /// </field>
        Constrained: null,
        GetPropertyValue: function (name, namespaceUri) {
            /// <summary>
            /// Method maps to COM IPrintSchemaOption::GetPropertyValue.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="namespaceUri" type="String" />
            /// <returns type="XML DOM" />
        },
        /// <field name="PagesPerSheet" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaNUpOption::PagesPerSheet. Valid for NUp option only.
        /// </field>
        PagesPerSheet: null,
        /// <field name="WidthInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageMediaSizeOption::WidthInMicrons. Valid for PageMediaSize option only.
        /// </field>
        WidthInMicrons: null,
        /// <field name="HeightInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageMediaSizeOption::HeightInMicrons. Valid for PageMediaSize option only.
        /// </field>
        HeightInMicrons: null

    });

IPrintSchemaOptionCollection = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaOptionCollection,
    null,
    {
        /// <field name="Count" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaOptionCollection::Count.
        /// </field>
        Count: null,
        GetAt: function (index) {
            /// <summary>
            /// Property-get maps to COM IPrintSchemaOptionCollection::GetAt.
            /// </summary>
            /// <param name="index" type="Number" integer="true" />
            /// <returns type="IPrintSchemaOption" />
        }
    });


IPrintSchemaFeature = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaFeature,
    IPrintSchemaDisplayableElement,
    {
        /// <field name="SelectedOption" type="IPrintSchemaOption">
        /// Property-set/get maps to COM IPrintSchemaFeature::SelectedOption.
        /// </field>
        SelectedOption: null,
        /// <field name="SelectionType" type="PrintSchemaSelectionType">
        /// Property-get maps to COM IPrintSchemaFeature::SelectionType.
        /// </field>
        SelectionType: null,
        GetOption: function (name, namespaceUri) {
            /// <summary>
            /// Method maps to COM IPrintSchemaFeature::GetOption.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="namespaceUri" type="String" />
            /// <returns type="IPrintSchemaOption" />
        },
        /// <field name="DisplayUI" type="Boolean">
        /// Property-get maps to COM IPrintSchemaFeature::DisplayUI.
        /// </field>
        DisplayUI: null
    });


IPrintSchemaPageImageableSize = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaPageImageableSize,
    IPrintSchemaElement,
    {
        /// <field name="ImageableSizeWidthInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::ImageableSizeWidthInMicrons.
        /// </field>
        ImageableSizeWidthInMicrons: null,
        /// <field name="ImageableSizeHeightInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::ImageableSizeHeightInMicrons.
        /// </field>
        ImageableSizeHeightInMicrons: null,
        /// <field name="OriginWidthInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::OriginWidthInMicrons.
        /// </field>
        OriginWidthInMicrons: null,
        /// <field name="OriginHeightInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::OriginHeightInMicrons.
        /// </field>
        OriginHeightInMicrons: null,
        /// <field name="ExtentWidthInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::ExtentWidthInMicrons.
        /// </field>
        ExtentWidthInMicrons: null,
        /// <field name="ExtentHeightInMicrons" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaPageImageableSize::ExtentHeightInMicrons.
        /// </field>
        ExtentHeightInMicrons: null
    });


IPrintSchemaCapabilities = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaCapabilities,
    IPrintSchemaElement,
    {
        GetFeatureByKeyName: function (keyName) {
            /// <summary>
            /// Method maps to COM IPrintSchemaCapabilities::GetFeatureByKeyName.
            /// </summary>
            /// <param name="keyName" type="String" />
            /// <returns type="IPrintSchemaFeature" />
        },
        GetFeature: function (name, namespaceUri) {
            /// <summary>
            /// Method maps to COM IPrintSchemaCapabilities::GetFeature.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="namespaceUri" type="String" />
            /// <returns type="IPrintSchemaFeature" />
        },
        /// <field name="PageImageableSize" type="IPrintSchemaPageImageableSize">
        /// Property-get maps to COM IPrintSchemaCapabilities::PageImageableSize.
        /// </field>
        PageImageableSize: null,
        /// <field name="JobCopiesAllDocumentsMinValue" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaCapabilities::JobCopiesAllDocumentsMinValue.
        /// </field>
        JobCopiesAllDocumentsMinValue: null,
        /// <field name="JobCopiesAllDocumentsMaxValue" type="Number" integer="true">
        /// Property-get maps to COM IPrintSchemaCapabilities::JobCopiesAllDocumentsMaxValue.
        /// </field>
        JobCopiesAllDocumentsMaxValue: null,
        GetSelectedOptionInPrintTicket: function (feature) {
            /// <summary>
            /// Method maps to COM IPrintSchemaCapabilities::GetSelectedOptionInPrintTicket.
            /// </summary>
            /// <param name="feature" type="IPrintSchemaFeature" />
            /// <returns type="IPrintSchemaOption" />
        },
        GetOptions: function (feature) {
            /// <summary>
            /// Method maps to COM IPrintSchemaCapabilities::GetOptions.
            /// </summary>
            /// <param name="feature" type="IPrintSchemaFeature" />
            /// <returns type="IPrintSchemaOptionCollection" />
        }
    });


IPrintSchemaTicket = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrintSchemaTicket,
    IPrintSchemaElement,
    {
        GetFeatureByKeyName: function (keyName) {
            /// <summary>
            /// Method maps to COM IPrintSchemaTicket::GetFeatureByKeyName.
            /// </summary>
            /// <param name="keyName" type="String" />
            /// <returns type="IPrintSchemaFeature" />
        },
        GetFeature: function (name, namespaceUri) {
            /// <summary>
            /// Method maps to COM IPrintSchemaTicket::GetFeature.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="namespaceUri" type="String" />
            /// <returns type="IPrintSchemaFeature" />
        },
        NotifyXmlChanged: function () {
            /// <summary>
            /// Method maps to COM IPrintSchemaTicket::NotifyXmlChanged.
            /// </summary>
        },
        GetCapabilities: function () {
            /// <summary>
            /// Method maps to COM IPrintSchemaTicket::GetCapabilities.
            /// </summary>
            /// <returns type="IPrintSchemaCapabilities" />
        },
        /// <field name="JobCopiesAllDocuments" type="Number" integer="true">
        /// Property-get/put maps to IPrintSchemaTicket::JobCopiesAllDocuments.
        /// </field>
        JobCopiesAllDocuments: null
    });


IPrinterScriptableSequentialStream = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterScriptableSequentialStream,
    null,
    {
        Read: function (count) {
            /// <summary>
            /// Method maps to COM IPrinterScriptableSequentialStream::Read.
            /// </summary>
            /// <param name="count" type="Number" integer="true" />
            /// <returns type="Array" />
        },
        Write: function (array) {
            /// <summary>
            /// Method maps to COM IPrinterScriptableSequentialStream::Write.
            /// </summary>
            /// <param name="array" type="Array" />
            /// <returns type="Number" integer="true"/>
        }
    });

IPrinterScriptableStream = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterScriptableStream,
    IPrinterScriptableSequentialStream,
    {
        Commit: function () {
            /// <summary>
            /// Method maps to COM IPrinterScriptableStream::Commit.
            /// </summary>
        },
        Seek: function (offset, streamSeek) {
            /// <summary>
            /// Method maps to COM IPrinterScriptableStream::Seek
            /// </summary>
            /// <param name="offset" type="Number" integer="true" />
            /// <param name="streamSeek" type="STREAM_SEEK" />
            /// <returns type="Number" integer="true"/>
        },
        SetSize: function (size) {
            /// <summary>
            /// Method maps to COM IPrinterScriptableStream::SetSize.
            /// </summary>
            /// <param name="size" type="Number" integer="true" />
        }
    });


IPrinterScriptablePropertyBag = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterScriptablePropertyBag,
    null,
    {
        GetBool: function (name) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::GetBool.
            /// </summary>
            /// <param name="name" type="String" />
            /// <returns type="Boolean" />
        },
        SetBool: function (name, value) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::SetBool.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="value" type="Boolean" />
        },
        GetInt32: function (name) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::GetInt32.
            /// </summary>
            /// <param name="name" type="String" />
            /// <returns type="Number" integer="true"/>
        },
        SetInt32: function (name, value) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::SetInt32.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="value" type="Number" integer="true" />
        },
        GetString: function (name) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::GetString.
            /// </summary>
            /// <param name="name" type="String" />
            /// <returns type="String" />
        },
        SetString: function (name, value) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::SetString.
            /// </summary>
            /// <param name="name" type="String" />
            /// <param name="value" type="String" />
        },
        GetReadStream: function (name) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::GetReadStream.
            /// </summary>
            /// <param name="name" type="String" />
            /// <returns type="IPrinterScriptableStream" />
        },
        GetWriteStream: function (name) {
            /// <summary>
            /// Method maps to COM IPrinterScriptablePropertyBag::GetWriteStream.
            /// </summary>
            /// <param name="name" type="String" />
            /// <returns type="IPrinterScriptableStream" />
        }
    });


IPrinterScriptContext = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterScriptContext,
    null,
    {
        /// <field name="DriverProperties" type="IPrinterScriptablePropertyBag">
        /// Property-get maps to COM IPrinterScriptContext::DriverProperties.
        /// </field>
        DriverProperties: null,
        /// <field name="QueueProperties" type="IPrinterScriptablePropertyBag">
        /// Property-get maps to COM IPrinterScriptContext::QueueProperties.
        /// </field>
        QueueProperties: null,
        /// <field name="UserProperties" type="IPrinterScriptablePropertyBag">
        /// Property-get maps to COM IPrinterScriptContext::UserProperties.
        /// </field>
        UserProperties: null
    });

IPrinterBidiSchemaElement = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterBidiSchemaElement,
    null,
    {
        /// <field name="Name" type="String">
        /// Property-get maps to COM IPrinterBidiSchemaElement::Name.
        /// </field>
        Name: null,
        /// <field type="PrinterBidiSchemaElementType">
        /// Property-get maps to COM IPrinterBidiSchemaElement::BidiType.
        /// </field>
        BidiType: null,
        /// <field type="Object">
        /// Property-get maps to COM IPrinterBidiSchemaElement::Value.
        /// </field>
        Value: null
    });

IPrinterBidiSchemaResponses = function () { }
v4PrintDriverIntellisense.createInterface(
    IPrinterBidiSchemaResponses,
    null,
    {
        AddNull: function (schema) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddNull.
            /// </summary>
            /// <param name="schema" type="String" />
        },
        AddString: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddString.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="String" />
        },
        AddText: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddText.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="String" />
        },
        AddEnum: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddEnum.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="String" />
        },
        AddInt32: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddInt32.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="Number" integer="true" />
        },
        AddBool: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddBool.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="Boolean" />
        },
        AddFloat: function (schema, value) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddFloat.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="value" type="Number" />
        },
        AddBlob: function (schema, array) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddBlob.
            /// </summary>
            /// <param name="schema" type="String" />
            /// <param name="array" type="Array" />
        },
        AddRequeryKey: function (queryKey) {
            /// <summary>
            /// Method maps to COM IPrinterBidiSchemaResponses::AddRequeryKey.
            /// </summary>
            /// <param name="queryKey" type="String" />
        }
    });

// SIG // Begin signature block
// SIG // MIIr4gYJKoZIhvcNAQcCoIIr0zCCK88CAQExDzANBglg
// SIG // hkgBZQMEAgEFADB3BgorBgEEAYI3AgEEoGkwZzAyBgor
// SIG // BgEEAYI3AgEeMCQCAQEEEBDgyQbOONQRoqMAEEvTUJAC
// SIG // AQACAQACAQACAQACAQAwMTANBglghkgBZQMEAgEFAAQg
// SIG // 1LV/aB9eI2uINXnZg7ToBXLLd3AbvtK4rpszLft0VuGg
// SIG // ghFuMIIIfjCCB2agAwIBAgITNgAAAg3ihA9J7tst/AAC
// SIG // AAACDTANBgkqhkiG9w0BAQsFADBBMRMwEQYKCZImiZPy
// SIG // LGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUw
// SIG // EwYDVQQDEwxBTUUgQ1MgQ0EgMDEwHhcNMjUxMDIzMjMw
// SIG // OTMwWhcNMjYwNDI2MjMxOTMwWjAkMSIwIAYDVQQDExlN
// SIG // aWNyb3NvZnQgQXp1cmUgQ29kZSBTaWduMIIBIjANBgkq
// SIG // hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqY/a8us+r9PE
// SIG // yHiqMUtvuXPdvEsGCg1wsj1mR6Zt8SB06gQZpUzNRju1
// SIG // +GqeY4/8K6B+087pCbXy0emeKwZI3ZaHB2CdqlO4IIpN
// SIG // RQ3lS9bjJ5eXzwAdBE46ra5Ny7dsU9u11KDZSn5xXJ5l
// SIG // aSGmen50gItpYhIWx6nHuahCWxsL+hYpYkic5JnkyumK
// SIG // EEOI6tJCvU6ARjJkYiymV0ztUggGuwePvehDCt8iiF5w
// SIG // THZyoVnsAbFPrdSx1rwfI7fKaAWEoOfvdRWn/aBQ75ef
// SIG // gRVlWyffpmFmzsyff2V9SeMr1KGQoWspChmk5ZOdQ1KG
// SIG // cprAbmrVmybBs6NHeN4DCwIDAQABo4IFijCCBYYwKQYJ
// SIG // KwYBBAGCNxUKBBwwGjAMBgorBgEEAYI3WwEBMAoGCCsG
// SIG // AQUFBwMDMD0GCSsGAQQBgjcVBwQwMC4GJisGAQQBgjcV
// SIG // CIaQ4w2E1bR4hPGLPoWb3RbOnRKBYIPdzWaGlIwyAgFk
// SIG // AgEOMIICdgYIKwYBBQUHAQEEggJoMIICZDBiBggrBgEF
// SIG // BQcwAoZWaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
// SIG // aWluZnJhL0NlcnRzL0JZMlBLSUNTQ0EwMS5BTUUuR0JM
// SIG // X0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcnQwUgYIKwYB
// SIG // BQUHMAKGRmh0dHA6Ly9jcmwxLmFtZS5nYmwvYWlhL0JZ
// SIG // MlBLSUNTQ0EwMS5BTUUuR0JMX0FNRSUyMENTJTIwQ0El
// SIG // MjAwMSgyKS5jcnQwUgYIKwYBBQUHMAKGRmh0dHA6Ly9j
// SIG // cmwyLmFtZS5nYmwvYWlhL0JZMlBLSUNTQ0EwMS5BTUUu
// SIG // R0JMX0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcnQwUgYI
// SIG // KwYBBQUHMAKGRmh0dHA6Ly9jcmwzLmFtZS5nYmwvYWlh
// SIG // L0JZMlBLSUNTQ0EwMS5BTUUuR0JMX0FNRSUyMENTJTIw
// SIG // Q0ElMjAwMSgyKS5jcnQwUgYIKwYBBQUHMAKGRmh0dHA6
// SIG // Ly9jcmw0LmFtZS5nYmwvYWlhL0JZMlBLSUNTQ0EwMS5B
// SIG // TUUuR0JMX0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcnQw
// SIG // ga0GCCsGAQUFBzAChoGgbGRhcDovLy9DTj1BTUUlMjBD
// SIG // UyUyMENBJTIwMDEsQ049QUlBLENOPVB1YmxpYyUyMEtl
// SIG // eSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZp
// SIG // Z3VyYXRpb24sREM9QU1FLERDPUdCTD9jQUNlcnRpZmlj
// SIG // YXRlP2Jhc2U/b2JqZWN0Q2xhc3M9Y2VydGlmaWNhdGlv
// SIG // bkF1dGhvcml0eTAdBgNVHQ4EFgQUupJfr2Xp4GgOwnPJ
// SIG // ybXerGETQN4wDgYDVR0PAQH/BAQDAgeAMEUGA1UdEQQ+
// SIG // MDykOjA4MR4wHAYDVQQLExVNaWNyb3NvZnQgQ29ycG9y
// SIG // YXRpb24xFjAUBgNVBAUTDTIzNjE2Nys1MDYwNDIwggHm
// SIG // BgNVHR8EggHdMIIB2TCCAdWgggHRoIIBzYY/aHR0cDov
// SIG // L2NybC5taWNyb3NvZnQuY29tL3BraWluZnJhL0NSTC9B
// SIG // TUUlMjBDUyUyMENBJTIwMDEoMikuY3JshjFodHRwOi8v
// SIG // Y3JsMS5hbWUuZ2JsL2NybC9BTUUlMjBDUyUyMENBJTIw
// SIG // MDEoMikuY3JshjFodHRwOi8vY3JsMi5hbWUuZ2JsL2Ny
// SIG // bC9BTUUlMjBDUyUyMENBJTIwMDEoMikuY3JshjFodHRw
// SIG // Oi8vY3JsMy5hbWUuZ2JsL2NybC9BTUUlMjBDUyUyMENB
// SIG // JTIwMDEoMikuY3JshjFodHRwOi8vY3JsNC5hbWUuZ2Js
// SIG // L2NybC9BTUUlMjBDUyUyMENBJTIwMDEoMikuY3JshoG9
// SIG // bGRhcDovLy9DTj1BTUUlMjBDUyUyMENBJTIwMDEoMiks
// SIG // Q049QlkyUEtJQ1NDQTAxLENOPUNEUCxDTj1QdWJsaWMl
// SIG // MjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1D
// SIG // b25maWd1cmF0aW9uLERDPUFNRSxEQz1HQkw/Y2VydGlm
// SIG // aWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENs
// SIG // YXNzPWNSTERpc3RyaWJ1dGlvblBvaW50MB8GA1UdIwQY
// SIG // MBaAFJZRhOBrb3v+2Aarw/KF5imuavnUMB8GA1UdJQQY
// SIG // MBYGCisGAQQBgjdbAQEGCCsGAQUFBwMDMA0GCSqGSIb3
// SIG // DQEBCwUAA4IBAQCShgfc8g1jf/bcAGOqgi53wwinPz7l
// SIG // 6AmCOUp6G7b9eUBwCcMASe5q/dOxJnMBAszJytjNmrlP
// SIG // zlB43V2FDhuU1eS+1sb39MQapblpXWY7579i+JgDSDpN
// SIG // fCoHEppYXVR0/AHXoR10rOzTBtnYtHD82PuDpdhCd58N
// SIG // iUmYpgUHUXKGcQ46AhhZh1fJTh6TtsH4WnKtE+TSteck
// SIG // KlxHU/okYr3YXYv59ukjrjw2umP3AinGtwkJaAkNSujV
// SIG // M7fj+hPBlvhbb3C82uXQFoyS1b33psFcpSRXZ6no2T22
// SIG // AUXTXn8i2YxbEUwWsTkZelxt5Is9resXhSy0UyYDzwE8
// SIG // dUuwMIII6DCCBtCgAwIBAgITHwAAAFHqj/accwyoOwAA
// SIG // AAAAUTANBgkqhkiG9w0BAQsFADA8MRMwEQYKCZImiZPy
// SIG // LGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRAw
// SIG // DgYDVQQDEwdhbWVyb290MB4XDTIxMDUyMTE4NDQxNFoX
// SIG // DTI2MDUyMTE4NTQxNFowQTETMBEGCgmSJomT8ixkARkW
// SIG // A0dCTDETMBEGCgmSJomT8ixkARkWA0FNRTEVMBMGA1UE
// SIG // AxMMQU1FIENTIENBIDAxMIIBIjANBgkqhkiG9w0BAQEF
// SIG // AAOCAQ8AMIIBCgKCAQEAyZpSCX0Bno1W1yqXMhT6BUlJ
// SIG // ZWpa4p3xFeiTHO4vm2Q6C/azR5xwxnyYHrkSGDtS2P9X
// SIG // +KDE64V20mmEQkubxnPNeOVnE2RvdPGxgwlq+BhS3ONd
// SIG // VsQPj79q7XgHM9HhzB9+qk0PC9KN1zm9p/seyiRS6JF1
// SIG // dbOqRf1pUl7FAVxmgiCFgV8hHIb/rDPXig7FDi3S0yEx
// SIG // 2CUDVpIq8jEhG8anUFE1WYxM+ni0S5KHwwKPKV4qyGDo
// SIG // DO+9AmDoma3Chyu5WDlW5cdtqXTWsGPE3umtnX6Amlld
// SIG // UFLms4OVR4guKf+n5LIBCC6bTiocfXPomqYjYTKx7AGM
// SIG // faVLaaXmhQIDAQABo4IE3DCCBNgwEgYJKwYBBAGCNxUB
// SIG // BAUCAwIAAjAjBgkrBgEEAYI3FQIEFgQUEmgkQiFHy9Rr
// SIG // vjHPIKTACyN/P0cwHQYDVR0OBBYEFJZRhOBrb3v+2Aar
// SIG // w/KF5imuavnUMIIBBAYDVR0lBIH8MIH5BgcrBgEFAgMF
// SIG // BggrBgEFBQcDAQYIKwYBBQUHAwIGCisGAQQBgjcUAgEG
// SIG // CSsGAQQBgjcVBgYKKwYBBAGCNwoDDAYJKwYBBAGCNxUG
// SIG // BggrBgEFBQcDCQYIKwYBBQUIAgIGCisGAQQBgjdAAQEG
// SIG // CysGAQQBgjcKAwQBBgorBgEEAYI3CgMEBgkrBgEEAYI3
// SIG // FQUGCisGAQQBgjcUAgIGCisGAQQBgjcUAgMGCCsGAQUF
// SIG // BwMDBgorBgEEAYI3WwEBBgorBgEEAYI3WwIBBgorBgEE
// SIG // AYI3WwMBBgorBgEEAYI3WwUBBgorBgEEAYI3WwQBBgor
// SIG // BgEEAYI3WwQCMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
// SIG // QwBBMAsGA1UdDwQEAwIBhjASBgNVHRMBAf8ECDAGAQH/
// SIG // AgEAMB8GA1UdIwQYMBaAFCleUV5krjS566ycDaeMdQHR
// SIG // CQsoMIIBaAYDVR0fBIIBXzCCAVswggFXoIIBU6CCAU+G
// SIG // MWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2lpbmZy
// SIG // YS9jcmwvYW1lcm9vdC5jcmyGI2h0dHA6Ly9jcmwyLmFt
// SIG // ZS5nYmwvY3JsL2FtZXJvb3QuY3JshiNodHRwOi8vY3Js
// SIG // My5hbWUuZ2JsL2NybC9hbWVyb290LmNybIYjaHR0cDov
// SIG // L2NybDEuYW1lLmdibC9jcmwvYW1lcm9vdC5jcmyGgaps
// SIG // ZGFwOi8vL0NOPWFtZXJvb3QsQ049QU1FUm9vdCxDTj1D
// SIG // RFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049
// SIG // U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUs
// SIG // REM9R0JMP2NlcnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/
// SIG // YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Q
// SIG // b2ludDCCAasGCCsGAQUFBwEBBIIBnTCCAZkwRwYIKwYB
// SIG // BQUHMAKGO2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
// SIG // a2lpbmZyYS9jZXJ0cy9BTUVSb290X2FtZXJvb3QuY3J0
// SIG // MDcGCCsGAQUFBzAChitodHRwOi8vY3JsMi5hbWUuZ2Js
// SIG // L2FpYS9BTUVSb290X2FtZXJvb3QuY3J0MDcGCCsGAQUF
// SIG // BzAChitodHRwOi8vY3JsMy5hbWUuZ2JsL2FpYS9BTUVS
// SIG // b290X2FtZXJvb3QuY3J0MDcGCCsGAQUFBzAChitodHRw
// SIG // Oi8vY3JsMS5hbWUuZ2JsL2FpYS9BTUVSb290X2FtZXJv
// SIG // b3QuY3J0MIGiBggrBgEFBQcwAoaBlWxkYXA6Ly8vQ049
// SIG // YW1lcm9vdCxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIw
// SIG // U2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJh
// SIG // dGlvbixEQz1BTUUsREM9R0JMP2NBQ2VydGlmaWNhdGU/
// SIG // YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
// SIG // aG9yaXR5MA0GCSqGSIb3DQEBCwUAA4ICAQBQECO3Tw/o
// SIG // 317Rrd7yadqcswPx1LvIYymkaTN6KcmuRt6HKa0Xe73U
// SIG // x2/AQ30TfgA9GBJngweRykKBusRzyOU17iIubJvy3gA2
// SIG // 1dwtqtB0DsoEv1U/ptVu2v++doTCJ/i+GbssVXkgaX8H
// SIG // +6EOGEmT4evp4GbwR4HwWlc+Dvf8HH8PdUA2Z04CvcwI
// SIG // fckSipbNm84jxJ8XjmTFTWscldL9edj2NsY6iGnyJFIy
// SIG // ur2PS7VRYyV3p1VAJp91gj1jRQtWEyCB8P5g9nE3z8u0
// SIG // ANaU/hjwEQCrdGyravWgnf2JtG+bT26YAokbc8m+32zU
// SIG // tXRO+NK3tAjhOu2FdsG3qNrF4sc7y37R/C+7Pcb/cFfh
// SIG // ttqsirepZii4xStcjMODYuXzGm3IJs0b0owHG6oKd7ZO
// SIG // GvHpmmh9K8/DLriD/sq8bURD10qi/wuW8zM7IpLg1vcR
// SIG // 9dIK2mc0pj44pc6UX0XbttP/VEJgu3lT2eI9VjWtaKjx
// SIG // 38xE9woSMyekPRtzTwgfuysF9DkJisr+yA4po/FPxpbB
// SIG // w9c/hBf32DH/GFxteS2pmjgKIbMP8sDukmEq3lVvuWNJ
// SIG // sybrZwQvQpvaM49fv+JKpLK5YWYEfwksYRR9wU8Hh/ID
// SIG // 9hRCEkbUoQ2W7mMpsp2Nbp/kcn4ivfolUy3Q9Yf0scsQ
// SIG // 6WTLYpm+AoCUJTGCGcwwghnIAgEBMFgwQTETMBEGCgmS
// SIG // JomT8ixkARkWA0dCTDETMBEGCgmSJomT8ixkARkWA0FN
// SIG // RTEVMBMGA1UEAxMMQU1FIENTIENBIDAxAhM2AAACDeKE
// SIG // D0nu2y38AAIAAAINMA0GCWCGSAFlAwQCAQUAoIGuMBkG
// SIG // CSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
// SIG // gjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJ
// SIG // BDEiBCA1CDqmrxz5WRmYSZwJXjIbpOH06lfyYucB149X
// SIG // b9mADjBCBgorBgEEAYI3AgEMMTQwMqAUgBIATQBpAGMA
// SIG // cgBvAHMAbwBmAHShGoAYaHR0cDovL3d3dy5taWNyb3Nv
// SIG // ZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBABwAwuG+fB0n
// SIG // uMi8xdTj77+8krxVRY/rEaLbc8Cg3nQd3r/wu1wO5Lxr
// SIG // ix8LGcli18bJrs3tm3+Ip/kyxKURzY49/QgJ3iwiBCoQ
// SIG // tZpBdyLvje5eiQLhzUJvuXYnj3MPKeIQ31w2R+oLEUZN
// SIG // vYsqQumheSvlk9On4f/4L4QiD5UgL8UgE2aDLcZhSSI8
// SIG // 4TIo2idUuAveg4yiDJqexgLh3z+/vWNRROkUq/W4OPJ1
// SIG // IGE84x86okCDCiCE4kRu/wU9RHWy2nHfGw991kffSTKM
// SIG // cV11/brTCMyeZZH27qFOVdhSMF22EZ8qts9tdEvoGAT5
// SIG // v7DDORRNEGyPisfoyrM4cSyhgheUMIIXkAYKKwYBBAGC
// SIG // NwMDATGCF4Awghd8BgkqhkiG9w0BBwKgghdtMIIXaQIB
// SIG // AzEPMA0GCWCGSAFlAwQCAQUAMIIBUgYLKoZIhvcNAQkQ
// SIG // AQSgggFBBIIBPTCCATkCAQEGCisGAQQBhFkKAwEwMTAN
// SIG // BglghkgBZQMEAgEFAAQgFopHYRFHOp43/1QgACAhh7Ky
// SIG // CtxiAWTQPmzXp1zpVDMCBmkg+MY2yBgTMjAyNTEyMDIx
// SIG // NzM2MjQuMDI4WjAEgAIB9KCB0aSBzjCByzELMAkGA1UE
// SIG // BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
// SIG // BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
// SIG // b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
// SIG // ZXJpY2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVs
// SIG // ZCBUU1MgRVNOOkE0MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
// SIG // ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIR
// SIG // 6jCCByAwggUIoAMCAQICEzMAAAICeVB0IRR9uKEAAQAA
// SIG // AgIwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMx
// SIG // EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
// SIG // ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
// SIG // dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
// SIG // bXAgUENBIDIwMTAwHhcNMjUwMTMwMTk0MjQ0WhcNMjYw
// SIG // NDIyMTk0MjQ0WjCByzELMAkGA1UEBhMCVVMxEzARBgNV
// SIG // BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
// SIG // HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEl
// SIG // MCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
// SIG // aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkE0
// SIG // MDAtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQg
// SIG // VGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0B
// SIG // AQEFAAOCAg8AMIICCgKCAgEAt3kqenLnFBjpHD4OLyli
// SIG // iXxEHrIStmQbGFNbQ1r0Lui/ZafnZ6q2oyHTXh9Rzd6M
// SIG // 94ohqCVrjdh1TWZHDrd/GlhnmzNIFFDrT47i4bjuXeu2
// SIG // KULBwSQFoXL3vzFXaED49Z44gI0ojqy/MRWqxSyOOkR/
// SIG // DXg4QD13CaVp+wCMwsiI2Tmidg1gPukMDc8KowYCKX9Y
// SIG // VhcKh7zxHnctJ6LV27Vn0/bwki/bHQyuivxx/R7GmOcC
// SIG // 5lFAe0n7ixqNTlhJujCchto4saovTckaMqXRfHUco1sS
// SIG // kZdiccL23rZQ04qOul5YkznJKtkYDPmaHGRG+hKDnbXd
// SIG // Fyody88dvQIR8ZZPuniMGr5R2Lji2QyqHTzlTeo9SCfW
// SIG // 66JWOpmW6EOdTqnuZxDOYf1iV9vBi2YqBJCTfKjnuT+T
// SIG // 9mMfR6Dqi7oF9NKgs8auAQ5vMR/ORysbygjuSopKKWkR
// SIG // hrUJV4w8rrDFpax3Mkreeg4S+HXFZ5+3Rby+dM70JRWT
// SIG // IVaHoVkkJJFrlJQgqiDq03u0W5p23SaLB/u5Qvp+d4Jy
// SIG // suDqGc7lHqswp0gdSTVzypyaIz9w3uccLKYubVL0BTX5
// SIG // Xxk7I2YEAIAwXYPwztExoC0Qyr2UAmeaiLl6UEcoN+8n
// SIG // OdXvec/FNpsrFNF50qVnooB6pMjgLQ33CKauRr+x1fnW
// SIG // tkcCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBTaBrm1D4z9
// SIG // n/In5CCr8Mta5Uh02TAfBgNVHSMEGDAWgBSfpxVdAF5i
// SIG // XYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5o
// SIG // dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
// SIG // bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
// SIG // MjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsG
// SIG // AQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
// SIG // cGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3Rh
// SIG // bXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8E
// SIG // AjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1Ud
// SIG // DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAg/N2
// SIG // hUFMTd+x5DqCQzNZmhxWVVBnKk0HD5zg+lKGETJgyr9B
// SIG // mmx5RPNgGICz7lZbpJ+x7STxds9I504AH0TJ9uiRSzxu
// SIG // zv12yituYawTyd9JQbsIwE1befFANQVqO5bJp8q7q/+o
// SIG // fABc618q17Zb80GKmkWGPZNFBWORjPp/WGhBCtg9uvHv
// SIG // mvhw5lnvrWC9h/vTuENTEC2oPnIjcC5I//kJcaV4lqLv
// SIG // SrwD9LSJPnx/Bd8MOVTk4vWmffqj47M8N9R+J3bYrwWW
// SIG // h+bOW6CZh9iW7TLn9su4UnSXRNFFtgdBRGTyyJnppSob
// SIG // JSTVahDu0T4Je3PNULlUjufH36Zm8LUsYWKxEt1bD4JV
// SIG // 5/Tgxew6pjzBvxsrAeKP0JKTVKvsEu2zkUzc6hzLR/qK
// SIG // 3dmEpmvtW8lga/4syCoIDgnRM2mQ38ptdhjOmuEviMug
// SIG // FCKe/yiKQJn1n163DCu1exAc8aHs5C0RBFiOF7T8KRAZ
// SIG // 7TmtaAx92f/nUcbMS9L4Mmu4zX6zu6Is0wJZ/9mQWAfY
// SIG // qFHqG4+QBi+OZtpnCkpOxxOc1EXlZCC6WCgUOfl//IxT
// SIG // tf6Wcqs0HiNf6Cf0S6InNUoni13xE/RFmSAY2TGfOOpg
// SIG // 26dcpyvVGzYgo0sJkxedPWJ/TOO1ULMbL9aJULuda1VR
// SIG // 5EjZvq06y8Ctbb4b9JkwggdxMIIFWaADAgECAhMzAAAA
// SIG // FcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGI
// SIG // MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
// SIG // bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
// SIG // cm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNy
// SIG // b3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkg
// SIG // MjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
// SIG // MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
// SIG // aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
// SIG // ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
// SIG // HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIC
// SIG // IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGm
// SIG // TOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YB
// SIG // f2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMM
// SIG // tY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTI
// SIG // cVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+
// SIG // NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5T
// SIG // z9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi9
// SIG // 47SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uD
// SIG // RedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tn
// SIG // YN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/Nme
// SIG // Rd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03
// SIG // dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
// SIG // TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy
// SIG // 16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkL
// SIG // iWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXps
// SIG // xREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqP
// SIG // nhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsG
// SIG // AQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqn
// SIG // Uv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVd
// SIG // AF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsG
// SIG // AQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8v
// SIG // d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVw
// SIG // b3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgw
// SIG // GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0P
// SIG // BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgw
// SIG // FoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
// SIG // TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29t
// SIG // L3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
// SIG // MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggr
// SIG // BgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
// SIG // L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0y
// SIG // My5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEs
// SIG // H2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfC
// SIG // cTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2Y
// SIG // urYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/
// SIG // SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRW
// SIG // qveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wX
// SIG // sFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixr
// SIG // e24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoy
// SIG // GtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8
// SIG // x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk
// SIG // 2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pF
// SIG // EUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq7
// SIG // 7EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
// SIG // onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1Zyvg
// SIG // DbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7
// SIG // vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0
// SIG // HVUzWLOhcGbyoYIDTTCCAjUCAQEwgfmhgdGkgc4wgcsx
// SIG // CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
// SIG // MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
// SIG // b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jv
// SIG // c29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsT
// SIG // Hm5TaGllbGQgVFNTIEVTTjpBNDAwLTA1RTAtRDk0NzEl
// SIG // MCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
// SIG // dmljZaIjCgEBMAcGBSsOAwIaAxUASYlIaQlgP91/42ci
// SIG // MtMnukScC86ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
// SIG // MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
// SIG // bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
// SIG // aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
// SIG // cCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsFAAIFAOzZTeEw
// SIG // IhgPMjAyNTEyMDIxMTM3MDVaGA8yMDI1MTIwMzExMzcw
// SIG // NVowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA7NlN4QIB
// SIG // ADAHAgEAAgILczAHAgEAAgIS4TAKAgUA7NqfYQIBADA2
// SIG // BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
// SIG // CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEB
// SIG // CwUAA4IBAQAhi2lpSHSlCu3RNDUjW2FR69Bc+L/pW9wM
// SIG // rw2CnsynbTuqSWgS7nJ3S6C+H1XKI5vzMmM+tkQVKymL
// SIG // UYFKK2CVFCqraGYER1nj24DapmMZQ03qpYYL7VIrpfSB
// SIG // unrgc6a8p6vOfK5tahe+9yvkseaF64gDcsNgWinjHfOp
// SIG // Mg4mfDYU+cHB1aAntwcpxTgISDK59PJKLgEa3siM+FVs
// SIG // fqfWCi6qINEX+Sw1ro2RnvgKDtxrwVGs1UfriRYkZ/W2
// SIG // bIdVjrjbKmSIzivAtq+ilUH9GRUCchf8oFsIHJ9HH9LL
// SIG // MGpilComrc75xEXuMv+DetT496x4VcSImnwM2WitSHj2
// SIG // MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzAR
// SIG // BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
// SIG // bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
// SIG // bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
// SIG // UENBIDIwMTACEzMAAAICeVB0IRR9uKEAAQAAAgIwDQYJ
// SIG // YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsq
// SIG // hkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgeExPp04j
// SIG // qQ4EDsJxhh95FZfTXv1cg/1ccwIti7/kKwUwgfoGCyqG
// SIG // SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDzjeoBGAeWy81y
// SIG // 1rlJi/GXfMVwLKl5LHnRcqJXzJRf7DCBmDCBgKR+MHwx
// SIG // CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
// SIG // MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
// SIG // b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
// SIG // c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACAnlQ
// SIG // dCEUfbihAAEAAAICMCIEILkthyZu46R6psXoiiDoPFLH
// SIG // ZoEJMI/xrJidddHQCPpNMA0GCSqGSIb3DQEBCwUABIIC
// SIG // AIx+w18Lo8mFLBOiYMzK68DKNILHq47kIxw8MBV99c9c
// SIG // BPO/i1QsGDLINBFPa9lETPd03yhVQUvnu7mb9wvxkGcm
// SIG // +yIrWiszEURCYM3I5MVlvfMSRkqxRLAWNupmWVk6eilR
// SIG // ve4c1fkVGLVyxMwL1XKZfV+4z2eBo6/n0Gh+6HVTsVzM
// SIG // z066tB4CX54GxchRP0QiNOwraVISGC6suUljQmXbE0Qw
// SIG // 4hJSzHdzuUGblyA1U2+2LEldy5iRwBcSSbXOauEreKXk
// SIG // RpqIS+ijiguh1Ri7EYvPkMogl/a3yenk4e43tuxeRRkl
// SIG // Y3PIncYiJpxorG/FUoMgoM9KI1EIglvTiX3dI5g1wy+9
// SIG // Qi/JzhjwGNRuuAuhR6TdjLFP0aQ/he9lvvkSV10/gqfX
// SIG // qL728R38M2mKxXDUjJDjXDCIj+JrTNupkdenpN9g5HGC
// SIG // TujmytGWFh9fTul2rjhUKxQTjJWVqocFwOXYtwUAOdDc
// SIG // G85z6aiiBu8LtBeDSS2SQnhZN/swFE8Dm/53TUdDo1vD
// SIG // wxRUghPJy+xBlgLn0dAmOsGFjR7NmAdqa1rp9y7Mbr+p
// SIG // lviUI8Ry6IBVQNMWp+7OGntQV+X5agoWWCDBDT5367wb
// SIG // xOHLXkBB/ItUIt1MfkSOnG94tpLaX/GAp0faAb2bMtKQ
// SIG // Aaoy8bi159/kVnbNsZ21EtiG
// SIG // End signature block
